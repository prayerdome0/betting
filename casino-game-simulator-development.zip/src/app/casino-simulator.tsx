"use client";

import { useMemo, useState } from "react";

type GameId =
  | "coin"
  | "roulette"
  | "dice"
  | "plinko"
  | "slots"
  | "mines"
  | "crash"
  | "towers";

type Game = {
  id: GameId;
  title: string;
  label: string;
  description: string;
  icon: string;
  tint: string;
  accent: string;
};

type HistoryItem = {
  game: string;
  result: string;
  amount: number;
  change: number;
  id: number;
};

const GAMES: Game[] = [
  {
    id: "coin",
    title: "Coin Flip",
    label: "CLASSIC",
    description: "Call the flip. Double the stakes.",
    icon: "◐",
    tint: "from-cyan-400/20 to-blue-600/5",
    accent: "text-cyan-200",
  },
  {
    id: "roulette",
    title: "Roulette",
    label: "TABLE",
    description: "Pick a color and let it spin.",
    icon: "◎",
    tint: "from-rose-500/20 to-orange-500/5",
    accent: "text-rose-200",
  },
  {
    id: "dice",
    title: "Dice Roll",
    label: "INSTANT",
    description: "Set your chance. Roll for a payout.",
    icon: "⚄",
    tint: "from-violet-500/20 to-fuchsia-500/5",
    accent: "text-violet-200",
  },
  {
    id: "plinko",
    title: "Plinko",
    label: "ARCADE",
    description: "Drop through the multiplier maze.",
    icon: "✦",
    tint: "from-amber-400/20 to-yellow-500/5",
    accent: "text-amber-100",
  },
  {
    id: "slots",
    title: "Lucky Slots",
    label: "SPIN",
    description: "Three reels. One big moment.",
    icon: "▦",
    tint: "from-pink-500/20 to-purple-600/5",
    accent: "text-pink-100",
  },
  {
    id: "mines",
    title: "Mines",
    label: "STRATEGY",
    description: "Find gems, avoid the hidden mines.",
    icon: "✹",
    tint: "from-emerald-400/20 to-teal-500/5",
    accent: "text-emerald-100",
  },
  {
    id: "crash",
    title: "Sky Crash",
    label: "LIVE",
    description: "Cash out before the rocket bursts.",
    icon: "↗",
    tint: "from-blue-500/20 to-indigo-600/5",
    accent: "text-blue-100",
  },
  {
    id: "towers",
    title: "Towers",
    label: "PICK",
    description: "Climb higher for every safe step.",
    icon: "▰",
    tint: "from-lime-400/20 to-green-500/5",
    accent: "text-lime-100",
  },
];

const currency = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
});

const rouletteRed = new Set([
  1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36,
]);

function Pill({ children, tone = "dark" }: { children: React.ReactNode; tone?: "dark" | "green" | "purple" }) {
  const styles = {
    dark: "border-white/10 bg-white/[0.045] text-slate-300",
    green: "border-emerald-400/20 bg-emerald-400/10 text-emerald-300",
    purple: "border-violet-400/20 bg-violet-400/10 text-violet-200",
  };

  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-bold tracking-[0.12em] ${styles[tone]}`}>{children}</span>;
}

export default function CasinoSimulator() {
  const [selectedGame, setSelectedGame] = useState<GameId>("coin");
  const [balance, setBalance] = useState(1250);
  const [amount, setAmount] = useState("25");
  const [coinPick, setCoinPick] = useState<"Heads" | "Tails">("Heads");
  const [roulettePick, setRoulettePick] = useState<"Red" | "Black">("Red");
  const [diceTarget, setDiceTarget] = useState(55);
  const [mineTiles, setMineTiles] = useState<number[]>([]);
  const [mineReveal, setMineReveal] = useState<number | null>(null);
  const [mineWasHit, setMineWasHit] = useState(false);
  const [towersStep, setTowersStep] = useState(0);
  const [result, setResult] = useState("Ready when you are.");
  const [resultTone, setResultTone] = useState<"neutral" | "win" | "loss">("neutral");
  const [lastRoll, setLastRoll] = useState<number | null>(null);
  const [lastRoulette, setLastRoulette] = useState<number | null>(null);
  const [coinFace, setCoinFace] = useState<"Heads" | "Tails">("Heads");
  const [slotReels, setSlotReels] = useState(["✦", "7", "♦"]);
  const [plinkoMultiplier, setPlinkoMultiplier] = useState<number | null>(null);
  const [crashPoint, setCrashPoint] = useState<number | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [roundKey, setRoundKey] = useState(0);
  const [history, setHistory] = useState<HistoryItem[]>([
    { id: 1, game: "Coin Flip", result: "Won · Heads", amount: 25, change: 25 },
    { id: 2, game: "Plinko", result: "Won · 1.4×", amount: 10, change: 4 },
    { id: 3, game: "Roulette", result: "Missed · Black", amount: 15, change: -15 },
  ]);

  const game = useMemo(() => GAMES.find((item) => item.id === selectedGame) ?? GAMES[0], [selectedGame]);
  const bet = Math.max(0, Number(amount) || 0);
  const diceMultiplier = (99 / Math.max(5, 100 - diceTarget)).toFixed(2);

  function addHistory(entry: Omit<HistoryItem, "id">) {
    setHistory((current) => [{ ...entry, id: Date.now() }, ...current].slice(0, 5));
  }

  function settle(gameName: string, label: string, multiplier: number, customBet = bet) {
    const change = multiplier > 0 ? Number((customBet * multiplier - customBet).toFixed(2)) : -customBet;
    setBalance((current) => Number((current + change).toFixed(2)));
    setResult(multiplier > 0 ? `Nice! ${label}` : label);
    setResultTone(multiplier > 0 ? "win" : "loss");
    addHistory({ game: gameName, result: label, amount: customBet, change });
  }

  function beginRound(message: string, duration: number, finish: () => void) {
    setIsPlaying(true);
    setRoundKey((current) => current + 1);
    setResult(message);
    setResultTone("neutral");
    window.setTimeout(() => {
      finish();
      setIsPlaying(false);
    }, duration);
  }

  function playGame() {
    if (isPlaying) return;
    if (!bet || bet > balance) {
      setResult(bet > balance ? "Not enough demo credits for that bet." : "Enter a bet amount first.");
      setResultTone("loss");
      return;
    }

    if (selectedGame === "coin") {
      const landed = Math.random() < 0.5 ? "Heads" : "Tails";
      beginRound("Coin is in the air…", 1350, () => {
        setCoinFace(landed);
        settle("Coin Flip", `${landed} landed`, landed === coinPick ? 2 : 0);
      });
      return;
    }
    if (selectedGame === "roulette") {
      const number = Math.floor(Math.random() * 37);
      const color = number === 0 ? "Green" : rouletteRed.has(number) ? "Red" : "Black";
      beginRound("Wheel is spinning…", 2100, () => {
        setLastRoulette(number);
        settle("Roulette", `${number} · ${color}`, color === roulettePick ? 2 : 0);
      });
      return;
    }
    if (selectedGame === "dice") {
      const roll = Math.ceil(Math.random() * 100);
      const won = roll >= diceTarget;
      setLastRoll(null);
      beginRound("Rolling the dice…", 950, () => {
        setLastRoll(roll);
        settle("Dice Roll", `Rolled ${roll} · Need ${diceTarget}+`, won ? Number(diceMultiplier) : 0);
      });
      return;
    }
    if (selectedGame === "plinko") {
      const multipliers = [0, 0.2, 0.4, 0.7, 1, 1.4, 2.2, 5];
      const landed = multipliers[Math.floor(Math.random() * multipliers.length)];
      setPlinkoMultiplier(null);
      beginRound("Ball is dropping through the board…", 1600, () => {
        setPlinkoMultiplier(landed);
        settle("Plinko", `Landed on ${landed}×`, landed);
      });
      return;
    }
    if (selectedGame === "slots") {
      const icons = ["7", "♦", "✦", "♛", "●"];
      const reels = Array.from({ length: 3 }, () => icons[Math.floor(Math.random() * icons.length)]);
      const isJackpot = reels[0] === reels[1] && reels[1] === reels[2];
      const isPair = reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2];
      beginRound("Reels are spinning…", 1550, () => {
        setSlotReels(reels);
        settle("Lucky Slots", isJackpot ? "Jackpot! Three matching reels" : isPair ? "Pair found" : "No matching reels", isJackpot ? 8 : isPair ? 1.5 : 0);
      });
      return;
    }
    if (selectedGame === "mines") {
      const tile = Math.floor(Math.random() * 25);
      const hitMine = Math.random() < 0.23;
      setMineReveal(null);
      beginRound("Searching the grid…", 800, () => {
        setMineReveal(tile);
        setMineWasHit(hitMine);
        if (!hitMine) setMineTiles((current) => [...current.slice(-5), tile]);
        settle("Mines", hitMine ? "A mine was hiding there" : "A bright gem uncovered", hitMine ? 0 : 1.35);
      });
      return;
    }
    if (selectedGame === "crash") {
      const point = Number((1 + Math.random() * 4.2).toFixed(2));
      const cashAt = 1.8;
      setCrashPoint(null);
      beginRound("Rocket is flying…", 2300, () => {
        setCrashPoint(point);
        settle("Sky Crash", `Rocket flew to ${point}×`, point >= cashAt ? cashAt : 0);
      });
      return;
    }
    const safe = Math.random() < 0.68;
    beginRound("Climbing the next floor…", 1050, () => {
      if (safe) setTowersStep((current) => Math.min(current + 1, 4));
      else setTowersStep(0);
      settle("Towers", safe ? `Safe step · floor ${towersStep + 1}` : "The tower crumbled", safe ? 1.45 : 0);
    });
  }

  function changeGame(id: GameId) {
    if (isPlaying) return;
    setSelectedGame(id);
    setResult("Pick a stake and play a free-credit round.");
    setResultTone("neutral");
  }

  function resetCredits() {
    if (isPlaying) return;
    setBalance(1250);
    setResult("Demo balance restored to $1,250.00.");
    setResultTone("neutral");
  }

  return (
    <main className="min-h-screen overflow-x-hidden bg-[#070b16] text-slate-100">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(46,211,183,.16),transparent_27%),radial-gradient(circle_at_85%_9%,rgba(105,88,255,.18),transparent_24%),linear-gradient(180deg,#0c1325_0%,#070b16_44%,#070b16_100%)]" />
      <div className="relative mx-auto max-w-[1540px] px-4 pb-10 pt-4 sm:px-6 lg:px-8">
        <header className="flex items-center justify-between gap-4 rounded-2xl border border-white/[0.08] bg-[#0d1425]/85 px-4 py-3 shadow-2xl shadow-black/20 backdrop-blur-xl sm:px-5">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-cyan-300 to-emerald-400 text-lg font-black text-slate-950 shadow-lg shadow-cyan-400/20">C</div>
            <div>
              <p className="text-[11px] font-black leading-none tracking-[0.2em] text-white">CROWNPLAY</p>
              <p className="mt-1 text-[9px] font-bold tracking-[0.16em] text-cyan-300">SIMULATOR</p>
            </div>
          </div>
          <nav className="hidden items-center gap-6 text-xs font-semibold text-slate-400 md:flex">
            <a className="text-white" href="#games">Games</a>
            <a href="#how-it-works" className="transition hover:text-white">How it works</a>
            <a href="#history" className="transition hover:text-white">My rounds</a>
          </nav>
          <div className="flex items-center gap-2">
            <Pill tone="green"><span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> DEMO MODE</Pill>
            <button disabled={isPlaying} onClick={resetCredits} className="hidden rounded-lg border border-white/10 bg-white/[0.045] px-3 py-1.5 text-xs font-semibold text-slate-200 transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-45 sm:block">Reset credits</button>
          </div>
        </header>

        <section className="mb-8 mt-9 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end">
          <div>
            <div className="mb-3 flex items-center gap-2 text-[11px] font-bold tracking-[0.14em] text-cyan-300"><span className="h-px w-7 bg-cyan-300" /> FREE-TO-PLAY CASINO LAB</div>
            <h1 className="max-w-3xl text-4xl font-black tracking-[-0.05em] text-white sm:text-5xl lg:text-6xl">Pick a game.<br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-200 via-emerald-200 to-lime-200">Play the odds.</span></h1>
            <p className="mt-4 max-w-xl text-sm leading-6 text-slate-400">Explore casino-style mini games with play credits only. No deposits, no withdrawals, just rounds to test your luck.</p>
          </div>
          <div className="flex min-w-[220px] items-center gap-3 rounded-2xl border border-emerald-400/15 bg-emerald-400/[0.07] p-4">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-emerald-400/15 text-lg">◈</div>
            <div>
              <p className="text-[10px] font-bold tracking-[0.13em] text-emerald-200/70">DEMO BALANCE</p>
              <p className="mt-0.5 text-xl font-black text-white">{currency.format(balance)}</p>
            </div>
          </div>
        </section>

        <section id="games" className="mb-6">
          <div className="mb-3 flex items-center justify-between"><h2 className="text-sm font-bold text-white">Choose your table</h2><span className="text-xs text-slate-500">8 games available</span></div>
          <div className="no-scrollbar flex gap-3 overflow-x-auto pb-2">
            {GAMES.map((item) => (
              <button disabled={isPlaying} key={item.id} onClick={() => changeGame(item.id)} className={`group min-w-[184px] flex-1 rounded-2xl border p-4 text-left transition duration-200 disabled:cursor-not-allowed disabled:opacity-55 ${selectedGame === item.id ? "border-cyan-300/50 bg-cyan-300/[0.10] shadow-[0_0_0_1px_rgba(103,232,249,.12),0_18px_38px_rgba(14,116,144,.16)]" : "border-white/[0.07] bg-white/[0.035] hover:border-white/[0.17] hover:bg-white/[0.065]"}`}>
                <div className={`mb-5 grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br ${item.tint} text-xl ${item.accent}`}>{item.icon}</div>
                <p className="text-sm font-bold text-white">{item.title}</p>
                <p className="mt-1 h-8 text-[11px] leading-4 text-slate-500">{item.description}</p>
                <div className="mt-3 text-[9px] font-bold tracking-[0.14em] text-slate-500">{item.label} <span className="float-right text-cyan-300 opacity-0 transition group-hover:opacity-100">PLAY →</span></div>
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_330px]">
          <div className="overflow-hidden rounded-3xl border border-white/[0.08] bg-[#0d1425]/80 shadow-2xl shadow-black/20">
            <div className="flex items-center justify-between border-b border-white/[0.08] px-5 py-4 sm:px-6">
              <div className="flex items-center gap-3"><div className={`grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br ${game.tint} text-lg ${game.accent}`}>{game.icon}</div><div><p className="text-sm font-bold text-white">{game.title}</p><p className="text-[10px] font-bold tracking-[0.13em] text-slate-500">{game.label} GAME</p></div></div>
              <Pill><span className="text-cyan-300">●</span> FAIR PLAY</Pill>
            </div>

            <div className="grid min-h-[415px] place-items-center p-5 sm:p-8">
              {selectedGame === "coin" && <CoinBoard pick={coinPick} setPick={setCoinPick} face={coinFace} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "roulette" && <RouletteBoard pick={roulettePick} setPick={setRoulettePick} result={lastRoulette} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "dice" && <DiceBoard target={diceTarget} setTarget={setDiceTarget} lastRoll={lastRoll} multiplier={diceMultiplier} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "plinko" && <PlinkoBoard multiplier={plinkoMultiplier} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "slots" && <SlotsBoard reels={slotReels} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "mines" && <MinesBoard tiles={mineTiles} reveal={mineReveal} hitMine={mineWasHit} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "crash" && <CrashBoard crashPoint={crashPoint} isPlaying={isPlaying} roundKey={roundKey} />}
              {selectedGame === "towers" && <TowersBoard step={towersStep} isPlaying={isPlaying} roundKey={roundKey} />}
            </div>
          </div>

          <aside className="rounded-3xl border border-white/[0.08] bg-[#0d1425]/90 p-5 shadow-2xl shadow-black/20 sm:p-6">
            <div className="flex items-center justify-between"><h2 className="font-bold text-white">Place demo bet</h2><Pill tone="purple">FREE CREDITS</Pill></div>
            <div className="mt-6">
              <div className="mb-2 flex justify-between text-[11px] font-bold text-slate-500"><label htmlFor="bet">BET AMOUNT</label><span>MAX {currency.format(balance)}</span></div>
              <div className="flex rounded-xl border border-white/[0.1] bg-[#070b16] p-1 focus-within:border-cyan-300/50">
                <span className="grid w-9 place-items-center text-sm font-bold text-slate-500">$</span>
                <input disabled={isPlaying} id="bet" value={amount} onChange={(event) => setAmount(event.target.value)} inputMode="decimal" className="min-w-0 flex-1 bg-transparent py-2 text-base font-bold text-white outline-none disabled:cursor-not-allowed disabled:opacity-50" />
                <button disabled={isPlaying} onClick={() => setAmount(String(Math.min(balance, bet ? bet * 2 : 25)))} className="rounded-lg bg-white/[0.07] px-2.5 text-[10px] font-bold text-slate-300 hover:bg-white/[0.12] disabled:cursor-not-allowed disabled:opacity-50">2×</button>
              </div>
              <div className="mt-2 grid grid-cols-4 gap-2">{[5, 10, 25, 50].map((value) => <button disabled={isPlaying} key={value} onClick={() => setAmount(String(value))} className="rounded-lg border border-white/[0.07] bg-white/[0.035] py-2 text-[11px] font-bold text-slate-400 transition hover:border-cyan-300/30 hover:text-white disabled:cursor-not-allowed disabled:opacity-50">${value}</button>)}</div>
            </div>

            <div className="my-6 border-t border-white/[0.08]" />
            <div className="space-y-3">
              <div className="flex justify-between text-xs"><span className="text-slate-500">Game</span><span className="font-semibold text-slate-200">{game.title}</span></div>
              <div className="flex justify-between text-xs"><span className="text-slate-500">Potential return</span><span className="font-semibold text-emerald-300">Up to {currency.format(selectedGame === "slots" ? bet * 8 : selectedGame === "plinko" ? bet * 5 : selectedGame === "crash" ? bet * 1.8 : selectedGame === "dice" ? bet * Number(diceMultiplier) : bet * 2)}</span></div>
              <div className="flex justify-between text-xs"><span className="text-slate-500">Your balance</span><span className="font-semibold text-slate-200">{currency.format(balance)}</span></div>
            </div>
            <button disabled={isPlaying} onClick={playGame} className="mt-7 w-full rounded-xl bg-gradient-to-r from-cyan-300 to-emerald-300 px-4 py-3.5 text-sm font-black text-slate-950 shadow-lg shadow-emerald-400/10 transition hover:brightness-110 active:scale-[0.99] disabled:cursor-wait disabled:opacity-75">{isPlaying ? "ANIMATING ROUND…" : `PLAY WITH ${currency.format(bet || 0)}`}</button>
            <div aria-live="polite" className={`mt-4 rounded-xl border px-3 py-3 text-center text-xs font-semibold ${isPlaying ? "round-status-active" : ""} ${resultTone === "win" ? "border-emerald-400/20 bg-emerald-400/[0.08] text-emerald-200" : resultTone === "loss" ? "border-rose-400/20 bg-rose-400/[0.08] text-rose-200" : "border-white/[0.07] bg-white/[0.035] text-slate-400"}`}>{result}</div>
            <p className="mt-5 text-center text-[10px] leading-4 text-slate-500">Practice only. Credits have no cash value and cannot be purchased or withdrawn.</p>
          </aside>
        </section>

        <section id="history" className="mt-6 grid gap-5 lg:grid-cols-[1.35fr_.65fr]">
          <div className="rounded-3xl border border-white/[0.08] bg-[#0d1425]/65 p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between"><div><h2 className="font-bold text-white">Recent rounds</h2><p className="mt-1 text-xs text-slate-500">Your latest practice table activity.</p></div><span className="text-[10px] font-bold tracking-[0.15em] text-slate-500">LIVE LOG</span></div>
            <div className="overflow-x-auto"><table className="w-full min-w-[490px] text-left text-xs"><thead className="text-[10px] font-bold tracking-[0.12em] text-slate-500"><tr className="border-b border-white/[0.07]"><th className="pb-3">GAME</th><th className="pb-3">ROUND</th><th className="pb-3 text-right">BET</th><th className="pb-3 text-right">RESULT</th></tr></thead><tbody>{history.map((item) => <tr key={item.id} className="border-b border-white/[0.05] last:border-0"><td className="py-3.5 font-semibold text-slate-200">{item.game}</td><td className="py-3.5 text-slate-500">{item.result}</td><td className="py-3.5 text-right text-slate-300">{currency.format(item.amount)}</td><td className={`py-3.5 text-right font-bold ${item.change >= 0 ? "text-emerald-300" : "text-rose-300"}`}>{item.change >= 0 ? "+" : ""}{currency.format(item.change)}</td></tr>)}</tbody></table></div>
          </div>
          <div id="how-it-works" className="rounded-3xl border border-cyan-300/10 bg-gradient-to-br from-cyan-300/[0.10] to-violet-500/[0.08] p-5 sm:p-6">
            <Pill tone="green">HOW IT WORKS</Pill>
            <h2 className="mt-4 text-xl font-black tracking-tight text-white">A casino feel,<br />without the stakes.</h2>
            <div className="mt-5 space-y-4">{[["01", "Start with free credits", "Your balance is for simulation only."],["02", "Try every game", "Switch games whenever you want."],["03", "Reset and replay", "Test strategies with zero pressure."]].map(([number, title, copy]) => <div key={number} className="flex gap-3"><span className="pt-0.5 text-[10px] font-black text-cyan-200">{number}</span><div><p className="text-xs font-bold text-white">{title}</p><p className="mt-0.5 text-[11px] leading-4 text-slate-400">{copy}</p></div></div>)}</div>
          </div>
        </section>
        <footer className="flex flex-col items-center justify-between gap-2 py-7 text-center text-[10px] font-semibold tracking-[0.08em] text-slate-600 sm:flex-row sm:text-left"><span>© 2026 CROWNPLAY SIMULATOR</span><span>FOR ENTERTAINMENT & PRACTICE ONLY · 18+</span></footer>
      </div>
    </main>
  );
}

function CoinBoard({ pick, setPick, face, isPlaying, roundKey }: { pick: "Heads" | "Tails"; setPick: (pick: "Heads" | "Tails") => void; face: "Heads" | "Tails"; isPlaying: boolean; roundKey: number }) {
  return <div className="w-full max-w-xl text-center"><div className="coin-stage"><div key={roundKey} className={`casino-coin ${isPlaying ? "is-flipping" : ""}`}><div className="coin-surface"><span className="text-5xl">{face === "Heads" ? "♛" : "♜"}</span><small>{face}</small></div></div></div><p className="mt-8 text-sm font-bold text-white">{isPlaying ? "The coin is tumbling…" : "Call the coin"}</p><p className="mt-1 text-xs text-slate-500">50% chance · 2.00× payout</p><div className="mx-auto mt-5 flex max-w-xs rounded-xl bg-[#070b16] p-1">{(["Heads", "Tails"] as const).map((side) => <button disabled={isPlaying} onClick={() => setPick(side)} key={side} className={`flex-1 rounded-lg py-2.5 text-xs font-bold transition disabled:cursor-not-allowed disabled:opacity-50 ${pick === side ? "bg-cyan-300 text-slate-950 shadow-lg" : "text-slate-400 hover:text-white"}`}>{side}</button>)}</div></div>;
}

function RouletteBoard({ pick, setPick, result, isPlaying, roundKey }: { pick: "Red" | "Black"; setPick: (pick: "Red" | "Black") => void; result: number | null; isPlaying: boolean; roundKey: number }) {
  const slots = Array.from({ length: 18 }, (_, index) => index + 1);
  return <div className="w-full max-w-xl text-center"><div className="roulette-stage"><span className="roulette-marker">▼</span><div key={roundKey} className={`roulette-wheel ${isPlaying ? "is-spinning" : ""}`}><div className="absolute inset-3 rounded-full border-4 border-dashed border-amber-100/45" />{slots.map((slot) => <span key={slot} style={{ transform: `rotate(${slot * 20}deg) translateY(-101px) rotate(-${slot * 20}deg)` }} className={`absolute grid h-7 w-7 place-items-center rounded-full text-[8px] font-black ${rouletteRed.has(slot) ? "bg-rose-500 text-white" : "bg-slate-950 text-slate-200"}`}>{slot}</span>)}<div className="grid h-20 w-20 place-items-center rounded-full border-4 border-amber-100/50 bg-emerald-600 text-2xl font-black text-white">{isPlaying ? "…" : result ?? "0"}</div></div></div><p className="mt-7 text-sm font-bold text-white">{isPlaying ? "No more bets — wheel spinning" : "Choose a color"}</p><div className="mx-auto mt-4 flex max-w-xs gap-2">{(["Red", "Black"] as const).map((color) => <button disabled={isPlaying} key={color} onClick={() => setPick(color)} className={`flex-1 rounded-xl border py-2.5 text-xs font-bold transition disabled:cursor-not-allowed disabled:opacity-50 ${pick === color ? color === "Red" ? "border-rose-300 bg-rose-500 text-white" : "border-white/40 bg-slate-950 text-white" : "border-white/10 bg-white/[.03] text-slate-400"}`}>{color}</button>)}</div></div>;
}

function DiceBoard({ target, setTarget, lastRoll, multiplier, isPlaying, roundKey }: { target: number; setTarget: (target: number) => void; lastRoll: number | null; multiplier: string; isPlaying: boolean; roundKey: number }) {
  return <div className="w-full max-w-2xl"><div key={roundKey} className={`casino-die mx-auto grid h-36 w-36 place-items-center rounded-[2rem] border border-violet-200/25 bg-gradient-to-br from-violet-500/70 to-fuchsia-700/80 text-6xl font-black text-white shadow-[0_16px_50px_rgba(139,92,246,.25)] ${isPlaying ? "is-rolling" : ""}`}>{isPlaying ? "…" : lastRoll ?? "?"}</div><div className="mx-auto mt-9 max-w-lg"><div className="flex justify-between text-xs font-bold"><span className="text-slate-400">Roll over <span className="text-white">{target}</span></span><span className="text-violet-200">{multiplier}× payout</span></div><input disabled={isPlaying} type="range" min="5" max="95" value={target} onChange={(event) => setTarget(Number(event.target.value))} className="mt-4 w-full accent-violet-400 disabled:cursor-not-allowed disabled:opacity-50" /><div className="mt-2 flex justify-between text-[10px] font-bold text-slate-600"><span>5</span><span>50</span><span>95</span></div></div></div>;
}

function PlinkoBoard({ multiplier, isPlaying, roundKey }: { multiplier: number | null; isPlaying: boolean; roundKey: number }) {
  const dots = Array.from({ length: 28 });
  const cells = ["0×", "0.2×", "0.4×", "0.7×", "1×", "1.4×", "2.2×", "5×"];
  return <div className="w-full max-w-xl text-center"><div className={`relative mx-auto h-[255px] max-w-[430px] overflow-hidden rounded-2xl border border-amber-200/10 bg-[radial-gradient(circle_at_50%_0%,rgba(251,191,36,.2),transparent_45%),#090d19] ${isPlaying ? "plinko-active" : ""}`}><div key={roundKey} className={`plinko-ball ${isPlaying ? "is-dropping" : ""}`} /><div className="grid grid-cols-7 gap-x-6 gap-y-5 px-10 pt-12">{dots.map((_, index) => <i key={index} className="mx-auto h-2.5 w-2.5 rounded-full bg-amber-100/70 shadow-[0_0_10px_rgba(251,191,36,.7)]" />)}</div><div className="absolute inset-x-2 bottom-2 grid grid-cols-8 gap-1">{cells.map((cell) => <span key={cell} className={`rounded-md py-2 text-[9px] font-black transition duration-300 ${!isPlaying && cell === `${multiplier}×` ? "bg-emerald-300 text-slate-950 shadow-[0_0_18px_rgba(110,231,183,.75)]" : "bg-white/[.08] text-slate-400"}`}>{cell}</span>)}</div></div><p className="mt-5 text-xs font-bold text-amber-100">{isPlaying ? "Following a randomized path…" : multiplier !== null ? `Last drop landed on ${multiplier}×` : "A randomized multiplier path awaits"}</p></div>;
}

function SlotsBoard({ reels, isPlaying, roundKey }: { reels: string[]; isPlaying: boolean; roundKey: number }) {
  return <div className="w-full max-w-lg text-center"><div className={`rounded-[2rem] border-[7px] border-pink-300/70 bg-gradient-to-b from-fuchsia-600 to-violet-800 p-5 shadow-[0_22px_60px_rgba(192,38,211,.22)] ${isPlaying ? "slot-machine-active" : ""}`}><div className="mb-3 flex justify-between px-3 text-[10px] font-black tracking-[0.2em] text-pink-100"><span>LUCKY</span><span>{isPlaying ? "SPIN" : "777"}</span></div><div className="grid grid-cols-3 gap-2 rounded-2xl bg-[#180c37] p-3">{reels.map((reel, index) => <div key={`${roundKey}-${index}`} className="slot-window grid aspect-square place-items-center overflow-hidden rounded-xl border border-violet-200/30 bg-gradient-to-b from-white to-pink-100 text-5xl text-violet-800 shadow-inner"><span style={{ animationDelay: `${index * 130}ms` }} className={isPlaying ? "slot-symbol is-spinning" : "slot-symbol"}>{isPlaying ? ["7", "♦", "✦"][index] : reel}</span></div>)}</div><p className="mt-3 text-[10px] font-bold tracking-[0.16em] text-pink-100">{isPlaying ? "REELS IN MOTION" : "MATCH 3 TO WIN 8×"}</p></div></div>;
}

function MinesBoard({ tiles, reveal, hitMine, isPlaying, roundKey }: { tiles: number[]; reveal: number | null; hitMine: boolean; isPlaying: boolean; roundKey: number }) {
  return <div className="w-full max-w-sm text-center"><div key={roundKey} className={`mines-grid grid grid-cols-5 gap-2 rounded-2xl border border-emerald-300/10 bg-[#091619] p-4 ${isPlaying ? "is-searching" : ""}`}>{Array.from({ length: 25 }, (_, index) => {
    const revealedNow = reveal === index;
    const previousGem = tiles.includes(index) && !revealedNow;
    const tileStyle = revealedNow ? hitMine ? "is-mine" : "is-gem" : previousGem ? "is-gem is-previous" : "is-hidden";
    return <div key={index} className={`mine-tile grid aspect-square place-items-center rounded-lg border text-sm ${tileStyle}`}>{revealedNow ? hitMine ? "✹" : "◆" : previousGem ? "◆" : "·"}</div>;
  })}</div><p className="mt-5 text-xs font-bold text-emerald-100">{isPlaying ? "Scanner is choosing a tile…" : "Each round uncovers a random tile · avoid the mines"}</p></div>;
}

function CrashBoard({ crashPoint, isPlaying, roundKey }: { crashPoint: number | null; isPlaying: boolean; roundKey: number }) {
  return <div className="w-full max-w-xl text-center"><div className={`crash-board relative h-[230px] overflow-hidden rounded-2xl border border-blue-300/10 bg-[linear-gradient(180deg,rgba(37,99,235,.18),transparent_70%),#080d1f] ${isPlaying ? "is-flying" : ""}`}><div className="absolute inset-x-0 bottom-0 h-px bg-blue-300/30" /><div className="crash-trail absolute bottom-6 left-[12%] h-px w-[78%] origin-left rotate-[-23deg] bg-gradient-to-r from-cyan-300 via-blue-400 to-transparent shadow-[0_0_18px_rgba(96,165,250,.8)]" /><span key={roundKey} className={`crash-rocket absolute right-[18%] top-[22%] text-5xl drop-shadow-[0_0_15px_rgba(125,211,252,.85)] ${isPlaying ? "is-launching" : ""}`}>🚀</span><span className="absolute left-[20%] top-[18%] text-[10px] tracking-[.25em] text-blue-200/50">AUTO CASHOUT 1.80×</span><div className="absolute inset-0 grid place-items-center"><div><p className={`text-5xl font-black tracking-tight text-white ${isPlaying ? "crash-counter" : ""}`}>{isPlaying ? "↑" : crashPoint ? `${crashPoint}×` : "1.00×"}</p><p className="mt-2 text-[10px] font-bold tracking-[0.16em] text-blue-200">{isPlaying ? "FLIGHT IN PROGRESS" : crashPoint ? "LAST FLIGHT" : "READY FOR TAKEOFF"}</p></div></div></div><p className="mt-5 text-xs font-bold text-blue-100">Cash out is automatically set at 1.80×</p></div>;
}

function TowersBoard({ step, isPlaying, roundKey }: { step: number; isPlaying: boolean; roundKey: number }) {
  const activeFloor = Math.min(step, 3);
  return <div className="w-full max-w-md text-center"><div key={roundKey} className={`tower-board mx-auto flex h-[270px] max-w-[290px] flex-col-reverse gap-2 rounded-t-[2rem] border-x border-t border-lime-200/15 bg-[linear-gradient(180deg,rgba(132,204,22,.12),transparent)] p-4 ${isPlaying ? "is-climbing" : ""}`}>{[0, 1, 2, 3].map((floor) => <div key={floor} className="grid flex-1 grid-cols-3 gap-2">{[0, 1, 2].map((cell) => {
    const isSafe = floor < step && cell === 1;
    const isTarget = isPlaying && floor === activeFloor && cell === 1;
    return <span key={cell} className={`tower-tile rounded-lg border ${isSafe ? "is-safe" : ""} ${isTarget ? "is-target" : ""}`}>{isSafe ? "✦" : isTarget ? "↑" : ""}</span>;
  })}</div>)}</div><p className="mt-5 text-xs font-bold text-lime-100">{isPlaying ? "Scaling the next floor…" : step ? `${step} safe ${step === 1 ? "floor" : "floors"} climbed` : "Climb safe floors to grow your multiplier"}</p></div>;
}
