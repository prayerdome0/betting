import CasinoSimulator from "./casino-simulator";

export default function HomePage() {
  return <CasinoSimulator />;
}
